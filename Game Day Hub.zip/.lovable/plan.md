## Plán: 4 skupiny + nový playoff "klasický pavouk"

### 1) Až 4 skupiny v nastavení turnaje

- V `TournamentSettingsDialog.tsx` (i ve formuláři vytvoření turnaje v `AdminSetup.tsx`) povolit volbu počtu skupin **2 / 3 / 4** (dnes obvykle 2).
- Generování skupin v `TournamentContext.tsx` / `src/utils/tournament.ts` (`generateGroups`, rozdělení týmů) upravit, aby zvládlo 3 a 4 skupiny — rovnoměrné rozdělení týmů, pojmenování `A / B / C / D`.
- Round-robin generátor zápasů zůstává — běží už nad libovolným počtem skupin.

### 2) Nový typ playoffu — výběr při vytváření turnaje

Přidat sloupec `tournaments.playoff_format` (`'placement' | 'bracket'`), default `'placement'` (stávající chování — zápasy o všechna umístění).

V `AdminSetup.tsx` a v `TournamentSettingsDialog.tsx` přidat select **"Typ playoff"**:
- **Zápasy o umístění** (stávající — beze změny chování).
- **Klasický pavouk** (nový — popsáno níže).

### 3) Samostatná délka playoff zápasů

Přidat sloupec `tournaments.playoff_match_duration_minutes` (nullable; když je `null`, použije se `match_duration_minutes` jako fallback).

V dialogu nastavení turnaje přidat pole **"Délka playoff zápasu (min)"** vedle stávající délky zápasu.

Generátor playoff rozpisu (časy slotů) bude pro playoff zápasy používat tuto novou délku.

### 4) Nasídění do nového playoffu — "layered cross-group ranking"

V `src/utils/tournament.ts` přidat funkci `computeOverallSeeding(tournament)`:

1. Spočítej standings pro každou skupinu (existující logika).
2. Seřaď týmy do globálního pořadí **po vrstvách**:
   - nejdřív všichni 1. ze skupin (mezi sebou seřazeni body / GD / vstřelené góly podle `tiebreakerRule`),
   - pak všichni 2.,
   - pak všichni 3.,
   - pak všichni 4. atd.
3. Vrátí pole `seeds[0..N-1]` → odpovídá pozicím 1..N.

### 5) Generování pavouka — flexibilně podle počtu týmů

Nová funkce `generateBracketPlayoff(tournament, seeds)`:

- Vstup: `seeds` (pole `teamId`) v pořadí 1..N.
- Pokud `N >= 12`: použij **12-team formát** (zbylé týmy nehrají PO):
  - Předkolo (round 10): `5v12, 6v11, 7v10, 8v9`
  - Čtvrtfinále (round 4): `1 vs W(5-12), 2 vs W(6-11), 3 vs W(7-10), 4 vs W(8-9)`
  - Semifinále (round 3): pavouk **1-4 vs 2-3** → `W(QF1=1) vs W(QF4=4)`, `W(QF2=2) vs W(QF3=3)`
  - Finále (round 1) + zápas o 3. místo (round 2)
- Pokud `8 <= N < 12`: zmenšené předkolo — vezmi spodní část tabulky tak, aby do QF doplnila 4 vítěze (např. `N=10`: předkolo `5v6, 7v10, 8v9` se nedá hezky; spíš varianta: top 4 přímo, zbytek `5vN, 6v(N-1), 7v(N-2), 8v(N-3)` jen pokud `N>=12`). Pro `N < 12` přejde do varianty **8-team bez předkola**: 1v8, 2v7, 3v6, 4v5 → SF → F+3.místo.
- Pokud `4 <= N < 8`: rovnou semifinále 1v4, 2v3 → F + 3. místo.
- Pokud `N < 4`: jen finále (případně + 3.místo když `N=3`).

Pavouk se ukládá do `playoff_matches` (existující tabulka) se stejným `round`/`position`/`label` schématem, jaké už používá `PlayoffBracket.tsx` (round 10 = předkolo, 1 = finále, 2 = o 3., 3 = SF, 4 = QF). Labely čitelně: `"Předkolo"`, `"Čtvrtfinále"`, `"Semifinále"`, `"Finále"`, `"O 3. místo"`.

Časy slotů: respektovat `playoffStartTime`, délku `playoff_match_duration_minutes`, hřiště round-robin přes `fieldCount`, zachovat existující anti-collision pravidla.

Postup vítězů mezi koly: po potvrzení skóre v `confirmPlayoffMatch` (v `TournamentContext`) doplnit vítěze do navazujícího zápasu — rozšířit existující logiku o případ `playoff_format='bracket'`.

### 6) UI playoff bracketu

`PlayoffBracket.tsx` rozšířit, aby uměl render **pavouka** (sloupce: Předkolo → Čtvrtfinále → Semifinále → Finále + zápas o 3.). Když je `tournament.playoffFormat === 'bracket'`, použij nový layout; jinak ponech stávající "zápasy o umístění".

### 7) Databáze

Migrace přidá do `tournaments`:
- `playoff_format text not null default 'placement'` (s CHECK `in ('placement','bracket')`)
- `playoff_match_duration_minutes int null`

Typy v `src/types/tournament.ts`: doplnit `playoffFormat: 'placement' | 'bracket'` a `playoffMatchDurationMinutes: number | null` do `Tournament`.

### Co se NEMĚNÍ

- Stávající turnaje s `playoff_format='placement'` se chovají úplně stejně.
- Skórování, real-time, role, archivace, export — beze změn.
- Funkce `shiftMatchTimes` / `shiftPlayoffTimes` (z minulého kola) zůstávají.

### Soubory k úpravě

- `supabase` migrace — 2 nové sloupce v `tournaments`.
- `src/types/tournament.ts` — rozšíření typu.
- `src/contexts/TournamentContext.tsx` — load/save nových polí, větvení v generování & potvrzování PO.
- `src/utils/tournament.ts` — `computeOverallSeeding`, `generateBracketPlayoff`, použití playoff délky.
- `src/pages/AdminSetup.tsx` — výběr počtu skupin (až 4), typ playoff, dvě délky.
- `src/components/tournament/TournamentSettingsDialog.tsx` — totéž pro editaci.
- `src/components/tournament/PlayoffBracket.tsx` — render pavouka.

### Otevřené body k potvrzení

- Pro `N` mezi 8 a 11: navrhuji **přeskočit předkolo** a hrát 8-team bracket (1v8…). Sedí to, nebo chceš jinou variantu?
- Při remíze v playoff: vynucené vítězné rozhodnutí (jako dnes — nelze potvrdit remízu). OK?
